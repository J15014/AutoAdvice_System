<?php

App::uses('Helper', 'View');

class BananaHelper extends Helper {

	public function peel() {
		return '<b>peeled</b>';
	}

}
