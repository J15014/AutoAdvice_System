<?php
App::uses('EmailComponent', 'Controller/Component');

/**
 * TestPluginEmailComponent
 *
 * @package       Cake.Test.TestApp.Plugin.TestPlugin.Controller.Component
 */
class TestPluginEmailComponent extends EmailComponent {
}
