<?php
App::uses('AppController', 'Controller');
/**
 * Environments Controller
 *
 * @property Environment $Environment
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class EnvironmentsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session', 'Flash');
	//レイアウトの読み込み
	public $layout = 'origiLay';
/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Environment->recursive = 0;
		$this->set('environments', $this->Paginator->paginate());
		$this->set('openweathers', $this->Paginator->paginate());


		//arpredicts : environments の結合 (温度)
		$PEsql  = "SELECT P.pdate, P.predtemp,  E.temperature FROM (SELECT from_unixtime(round(unix_timestamp(pdatetime) div (15 * 60)) * (15 * 60)) AS pdate,predtemp FROM arpredicts GROUP BY pdate DESC LIMIT 96) AS P LEFT OUTER JOIN (SELECT from_unixtime(round(unix_timestamp(uploaded) div (15 * 60)) * (15 * 60)) AS upload,temperature FROM environments GROUP BY upload DESC LIMIT 96) AS E  ON P.pdate = E.upload;";



		$PEdatas = $this->Environment->query($PEsql, false);
		$this->set('PEtemps', $PEdatas);
		//arpredicts : environments の結合(湿度)
		$PEsql2 = "SELECT P.pdate, P.predhumid,  E.humid FROM (SELECT from_unixtime(round(unix_timestamp(pdatetime) div (15 * 60)) * (15 * 60)) AS pdate,predhumid FROM arpredicts GROUP BY pdate DESC LIMIT 96) AS P LEFT OUTER JOIN (SELECT from_unixtime(round(unix_timestamp(uploaded) div (15 * 60)) * (15 * 60)) AS upload,humid FROM environments GROUP BY upload DESC LIMIT 96) AS E  ON P.pdate = E.upload;";



		$PEdatas2 = $this->Environment->query($PEsql2, false);
		$this->set('PEhumids', $PEdatas2);

		//OpenWhethers
		$Osql = "select * from openweathers order by id desc LIMIT 96;";
		$Odatas = $this->Environment->query($Osql, false);
		$this->set('openweathers', $Odatas);

		//prediction
		$this->set('arpredicts', $this->Paginator->paginate());
		$pSql = "select predtemp from arpredicts where id =(select max(id) from arpredicts);";
		$Pdata = $this->Environment->query($pSql, false);
		$Pdata2 = $Pdata[0]['arpredicts']['predtemp'];
		$this->set('arpretemp', $Pdata2);

		//roomTemp
		$Rsql = "select temperature from environments where id = (select max(id) from environments);";
		$Rdata = $this->Environment->query($Rsql, false);
		$Rdata2 = $Rdata[0]['environments']['temperature'];
		$this->set('roomTemp', $Rdata2);

		//comfortV
		$this->set('arpredicts', $this->Paginator->paginate());
		$pSql2 = "select predcomfort from arpredicts where id =(select max(id) from arpredicts);";
		$Pdata3 = $this->Environment->query($pSql2, false);
		$Pdata4 = $Pdata3[0]['arpredicts']['predcomfort'];
		$this->set('arcom', $Pdata4);







	}
}

?>
