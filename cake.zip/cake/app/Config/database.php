<?php
class DATABASE_CONFIG {

	public $test = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'user',
		'password' => 'password',
		'database' => 'test_database_name',
	);
	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => '127.0.0.1',
		'port' => 8888,
		'login' => 'j15009',
		'password' => 'j15009',
		'database' => 'live2',
		'encoding' => 'utf8'
	);
	public $environments = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => '127.0.0.1',
		'port' => '3306',
		'login' => 'j15009',
		'password' => 'j15009',
		'database' => 'live',
		'encoding' => 'utf8',
	);


}
