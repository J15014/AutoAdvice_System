

$(function(){
var showFlg = 0;

var ua = navigator.userAgent;
    if (ua.indexOf('iPhone') > 0 || ua.indexOf('Android') > 0 && ua.indexOf('Mobile') > 0) {
        // スマートフォン用コード
        $('html').css('font-size','150%').css('max-width','wrap-content').css('width', 'wrap-content');
        $('input').css('transform','scale(1.0)').css('margin','0.5em');
        $('.nav-table .btnOn, .btnOff, .btnO, .btnR').css('width', '40%').css('font-size', '80%');
        $('#chart_divO, #chart_divTe', '#chart_divO').css('width', 'wrap-content');
        $('#nav-content').css('width', '100%');
        $('#nav-input:checked ~ #nav-open').css('transform',  'translate(0%, -160%)');



    } else if (ua.indexOf('iPad') > 0 || ua.indexOf('Android') > 0) {
        // タブレット用コード
        $('html').css('font-size','150%');
        $('input').css('transform','scale(1.2)').css('margin','0.5em');

    } else {
        // PC用コード
        $('.nav-table .btnOn, .btnOff, .btnO, .btnR').css('width', '49%').css('font-size', '200%');


    }


$('#chart_divO').css('visibility', 'hidden');



  $('.btnOn').on('click',function(){

      if(showFlg == 0){


            $('#chart_divTe').css('visibility', 'visible');
            $('#chart_divHu').css('visibility', 'visible');
            $('#chart_divO').css('visibility', 'hidden');
            $("html,body").animate({scrollTop:$('#chart_divTe').offset().top});





      } else {

            $('#chart_divTe').css('visibility', 'hidden');
            $('#chart_divHu').css('visibility', 'hidden');
            $('#chart_divO').css('visibility', 'visible');
            $("html,body").animate({scrollTop:$('#chart_divO').offset().top});
      }


});
    $('.btnOff').on('click',function(){

        $('#chart_divTe').css('visibility', 'hidden');
        $('#chart_divO').css('visibility', 'hidden');
        $('#chart_divHu').css('visibility', 'hidden');

    });

    $('.btnR').on('click', function(){

      showFlg = 0;
      $('#chart_divTe').css('visibility', 'visible');
      $('#chart_divHu').css('visibility', 'visible');
      $('#chart_divO').css('visibility', 'hidden');
      $("html,body").animate({scrollTop:$('#chart_divTe').offset().top});


    });

    $('.btnO').on('click', function(){

      showFlg = 1;
      $('#chart_divTe').css('visibility', 'hidden');
      $('#chart_divHu').css('visibility', 'hidden');
      $('#chart_divO').css('visibility', 'visible');
      $("html,body").animate({scrollTop:$('#chart_divO').offset().top});


     });








});
