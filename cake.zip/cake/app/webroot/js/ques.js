$(function(){

    $('.btn1').on('click',function(){

      $('#chart_divCo').fadeIn();

    });

    $('.btn2').on('click',function(){

      $('#chart_divCo').fadeOut();

    });

    $('.btn3').on('click',function(){

      $('#chart_divLi').fadeIn();

    });
    $('.btn4').on('click',function(){

      $('#chart_divLi').fadeOut();

    });

    $('.btn5').on('click', function(){

      $('#chart_divHu').fadeIn();

    });

    $('.btn6').on('click', function(){

      $('#chart_divHu').fadeOut();

     });





});
