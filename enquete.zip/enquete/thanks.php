<!DOCTYPE html>
<html lang="ja" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>ありがとう画面</title>
  <link rel="stylesheet" href="css/stylesheet.css">
  <link rel="stylesheet" href="css/bootstrap-reboot.css">
	<script src="js/jquery.min.js" type="text/javascript"></script>
</head>
<body>
  <div class="thanks">
    <b>ありがとうございました</b>
  </div>
  <div class="page">
    <a href="./index.php"><button type="button" name="move">別の回答を送信する</button></a>
  </div>
</body>
</html>


<?php
//セッションの開始
// session_start();
// if(empty($_SESSION)){
//   exit;
// }
//
//   //接続設定
//   $dbtype="mysql";
//   $sv="192.168.2.2";
//   $dbname="test1";
//   $user="j15009";
//   $pass="j15009";
//
//   //データベースに接続
//   $dsn="$dbtype:host=$sv;dbname=$dbname;charset=utf8";
//   //$conn=new PDO("mysql:dbname=test1;host=localhost;charset=utf8","j15009","j15009");
//    $conn=new PDO($dsn,$user,$pass);
//
//
//
//
  //⼊⼒内容の取得（$_SESSIONから）
  // $gender=htmlspecialchars($_POST["gender"],ENT_QUOTES,"utf-8");
  $place=htmlspecialchars($_POST["place"],ENT_QUOTES,"utf-8");
  // $people=htmlspecialchars($_POST["people"],ENT_QUOTES,"utf-8");
  $comfort=htmlspecialchars($_POST["comfort"],ENT_QUOTES,"utf-8");
  // $windowopen=htmlspecialchars($_POST["winopen"],ENT_QUOTES,"utf-8");
  // $blindopen=htmlspecialchars($_POST["blindopen"],ENT_QUOTES,"utf-8");
  // $countpc=htmlspecialchars($_POST["countpc"],ENT_QUOTES,"utf-8");
  $airflg=htmlspecialchars($_POST["flg"],ENT_QUOTES,"utf-8");
  $airtemp=htmlspecialchars($_POST["airtemp"],ENT_QUOTES,"utf-8");
  $airmode=htmlspecialchars($_POST["airmode"],ENT_QUOTES,"utf-8");
  // $roomtemp=htmlspecialchars($_POST["roomtemp"],ENT_QUOTES,"utf-8");



  if($place == '-'){
    $place = 0;
  }

  // echo '$gender'.$gender;
  // echo '<br>';
  // echo '$place'.$place;
  // echo '<br>';
  // echo '$people'.$people;
  // echo '<br>';
  // echo '$comfort'.$comfort;
  // echo '<br>';
  // echo '$windowopen'.$windowopen;
  // echo '<br>';
  // echo '$blindopen'.$blindopen;
  // echo '<br>';
  // // echo $roomtemp;
  // // echo '<br>';
  // echo '$countpc'.$countpc;
  // echo '<br>';
  // echo '$airflg'.$airflg;
  // echo '<br>';
  // echo '$airtemp'.$airtemp;
  if ( $airtemp == '-'){
    $airtemp = 0;
  }
  // echo '<br>';
  // echo '$airmode'.$airmode;
  if ( $airmode == '-'){
    $airmode = 0;
  }
  // echo '<br>';
  // print('<p>'+$gender+'</p>');

  // ここのパスは機種依存のため $ which pythonで調べること
  $path = '/usr/bin/python3';
  // echo $path;
  // $cmd = $path+' ./transDb.py'+' '+$gender+' '+$place+' '+$people+' '+$comfort+' '+$windowopen+' '+$blindopen+' '+$roomtemp+' '+$countpc+' '+$airflg+' '+$airtemp;
  $cmd = $path." ./transDb.py"." ".$place." ".$comfort." ".$airflg." ".$airtemp." ".$airmode;
  $fullPath = $cmd;

  // echo '<br>';
  // echo $cmd;
  // echo '<br>';
  exec($fullPath, $outpara, $returnpara);
  // echo $returnpara;
  // var_dump($outpara);
//
//  //PHPで構築した時の残骸
//   //データの追加
//   $sql="INSERT INTO Questions(gender,place,people,comfort,windowopen,blindopen,roomtemp,countpc,airflg,airtemp,uploaded)
//   VALUES(gender,place,people,comfort,winopen,blindopen,roomtemp,countpc,airflg,airtemp,NOW())";
//
//   //データの取得
//   $stmt=$conn->prepare($sql);
//
//   $stmt->bindParam("gender",$gender);
//   $stmt->bindParam("place",$place);
//   $stmt->bindParam("people",$people);
//   $stmt->bindParam("comfort",$comfort);
//   $stmt->bindParam("winopen",$winopen);
//   $stmt->bindParam("blindopen",$blindopen);
//   $stmt->bindParam("roomtemp",$roomtemp);
//   $stmt->bindParam("countpc",$countpc);
//   $stmt->bindParam("airflg",$airflg);
//   $stmt->bindParam("airtemp",$airtemp);
//   //実行
//   $stmt->execute();
//
//   // $sql="SELECT*FROM test1 WHERE(gender=gender);";
//   // $sql="SELECT*FROM test1 WHERE(place=place);";
//   // $sql="SELECT*FROM test1 WHERE(people=people);";
//   // $sql="SELECT*FROM test1 WHERE(comfort=comfort);";
//   // $sql="SELECT*FROM test1 WHERE(winopen=winopen);";
//   // $sql="SELECT*FROM test1 WHERE(blindopen=blindopen);";
//   // $sql="SELECT*FROM test1 WHERE(roomtemp=roomtemp);";
//   // $sql="SELECT*FROM test1 WHERE(countpc=countpc);";
//   // $sql="SELECT*FROM test1 WHERE(airflg=airflg);";
//   // $sql="SELECT*FROM test1 WHERE(airtemp=airtemp);";
//
//
//
//   //$row=$stmt->fetch();
//
//
//
//
//   エラーチェック
//   $error=$stmt->errorInfo();
//   if($error[0]!="00000"){
//     $message="データの追加に失敗しました。{$error[2]}";
//   }else{
//     $message="データを追加しました。データ番号：".$conn->lastInsertId();
//   }
//   セッションデータの破棄
//   $_SESSION=array();
//   session_destroy();
  ?>
