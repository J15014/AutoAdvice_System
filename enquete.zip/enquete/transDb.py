# file name: call_from_php.py

# こんな風に呼び出す
# <?php
# // file name: call_python.php
#     $fullPath ='python3 ./cgi-bin/call_from_php.py abcd ddd eee rrr';
#     exec($fullPath, $outpara);
#     var_dump($outpara[0]);
# ?>

import sys
import datetime
# mysql connect
import mysql.connector

def main():
    argv = sys.argv
    gender = 0
    place = argv[1]
    people = 0
    comfort = argv[2]
    windowopen = 0
    blindopen = 0
    roomtemp =0
    countpc = 0
    airflg = argv[3]
    airtemp = argv[4]
    airmode = argv[5]
    # uploaded = argv[10]
    # gender = 1
    # place = 2
    # people = 3
    # comfort = 4
    # windowopen = 5
    # blindopen = 6
    # roomtemp = 7.0
    # countpc = 8
    #
    # airflg = 9
    # airtemp = 10
    # uploaded = 11

    date = datetime.datetime.now()
    date_txt = date.strftime('%Y-%m-%d %H:%M:%S')

    conn = mysql.connector.connect(user='j15009', password='j15009', host='localhost', port='3306', database='live')
    cur = conn.cursor()


    sql = 'select temperature,humid from live.environments order by id desc limit 1;'

    cur.execute(sql)

    room = cur.fetchall()
    print(room[0][0], room[0][1])
    roomtemp = str(room[0][0])
    roomhumid = str(room[0][1])


    # DB connector
    # conn = mysql.connector.connect(user='root', password='root', host='localhost', port='3306', database='test1')
    conn = mysql.connector.connect(user='j15009', password='j15009', host='localhost', port='3306', database='questions')
    cur = conn.cursor()


    # sql = "insert into Questions(gender, place, people, comfort, windowopen, blindopen, roomtemp, countpc, airflg, airtemp, uploaded) values ("+ gender +","+ place +","+ people +","+ comfort +","+ windowopen +","+ blindopen +","+ roomtemp +","+ countpc +","+ airflg +","+ airtemp +","+ uploaded +","+ date_txt +");"
    sql = "insert into Questions("
    sql += "place, "
    sql += "comfort, "
    sql += "roomtemp, roomhumid, airflg, airtemp, "
    sql += "airmode, uploaded) values ("
    sql += str(place) +","
    sql += str(comfort) +","
    sql += roomtemp +","+ roomhumid +","+ str(airflg) +","+ str(airtemp) +","
    sql += str(airmode) +",'"+ str(date_txt) +"');"
    print(sql);

    try:
        cur.execute(sql)
        conn.commit()
    except:
        conn.rollback()
        raise

    cur.close()
    conn.close()

if __name__=='__main__':
    main()
