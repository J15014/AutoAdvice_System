<?php print("<p>快適度の調査アンケートです。</p>"); ?>
<!DOCTYPE html>
<html lang="ja-JP" dir="ltr">
<head>
	<link rel="stylesheet" href="css/stylesheet.css">
	<!-- <link rel="stylesheet" href="https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/css/bootstrap-reboot.css"> -->
	<link rel="stylesheet" href="css/bootstrap-reboot.css">
	<script src="js/jquery.min.js" type="text/javascript">
	</script>
	<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> -->
	<meta charset="utf-8">
	<title>快適度調査</title>
</head>
<body>
	<p>アンケートにご協力ください<b>全3問</b><button type="button" id='debug-btn' hidden>デバッグ用</button></p>
	<!-- ここのactionを変更する -->
	<form id="form" action="thanks.php" method="post">
		<div class="where-class">
			<div class="question">
				<p>1. どこの教室ですか？</p>
				</div>
			<select class="question-2" name="place">
				<option value="-">選択してください</option>
				<!-- <option value="101">ホール</option>
				<option value="201">旧MediaCreationSuite</option>
				<option value="202">2F IT Solution Suite</option>
				<option value="203">2F System Network Suit</option>
				<option value="204">2F Game Design Suite</option>
				<option value="205">2F Medical \u0026 Business Suite</option>
				<option value="206">2F CAD Design Suite</option>
				<option value="207">2F CG Creation Suite</option>
				<option value="301">3A1 P1 CADデザイン科 1年</option>
				<option value="302">3A2 CP1 コンピューター科プログラムコース 1年</option>
				<option value="303">3A3 Y1 CG技術科</option>
				<option value="304">3B1 CP1 コンピュータ科プログラムコース 1年</option>
				<option value="305">3B2 CP2 コンピュータ科プログラムコース 2年</option>
				<option value="401">4A1 A2 ゲームクリエイト科 2年</option>
				<option value="402">4A2 A1 ゲームクリエイト科 1年</option>
				<option value="403">4A3 D1 建築科</option>
				<option value="404">4B1 M2 医療事務科 2年</option>
				<option value="405">4B2 CB2 コンピュータ科ビジネスコース 2年</option> -->
				<option value="406">4B3 J2 みらい情報科 2年</option>
				<option value="407">4B4 J3 みらい情報科 3年</option>
				<!-- <option value="408">4B5 E3 広告・Webデザイン科 3年</option>
				<option value="409">4B6 E2 広告・Webデザイン科 2年</option> -->
				<option value="501">5A1 J4 みらい情報科 4年</option>
				<option value="502">5A2 J1 みらい情報科1年</option>
				<!-- <option value="503">D2 建築家 2年</option>
				<option value="504">5A4 製図室</option>
				<option value="505">5B1 V2 CG・アニメーション科 2年</option>
				<option value="506">5B2 V3 CG・アニメーション科3年</option>
				<option value="507">5B3 A3 ゲームクリエイト科 3年</option>
				<option value="508">5B4 CB1 コンピュータ科ビジネスコース 1年</option> -->
			</select>
		</div>
		<div class="comfort-value">
			<div class="question">
				<p><b class="error error-4">必須項目</b>2. 快適度はどのくらいですか？</p>
			</div>
			<div class="question-4">
				<input class="comfort-radio" type="radio" name="comfort" value="1">暑い</input>
				<input class="comfort-radio" type="radio" name="comfort" value="0">快適</input>
				<input class="comfort-radio" type="radio" name="comfort" value="-1">寒い</input>
			</div>
		</div>
		<div class="airflg">
			<div class="question">
				<p>3. エアコンは付いていますか？</p>
			</div>
			<div id="question-9" class="question-9">
				<input id="flg-1" class="airflg-radio" type="radio" name="flg" value="1">付いている</input>
				<input id="flg-0" class="airflg-radio" type="radio" name="flg" value="0">付いていない</input>
			</div>
		</div>
		<div id="air-controll" class="air-controll">
			<div class="question">
				<p>エアコンの温度は何度ですか？</p>
			</div>
			<select class="question-10" name="airtemp">
				<option value="-">選択してください</option>
				<option value="18">18°C以下</option>
				<option value="19">19°C</option>
				<option value="20">20°C</option>
				<option value="21">21°C</option>
				<option value="22">22°C</option>
				<option value="23">23°C</option>
				<option value="24">24°C</option>
				<option value="25">25°C</option>
				<option value="26">26°C</option>
				<option value="27">27°C</option>
				<option value="28">28°C</option>
				<option value="29">29°C</option>
				<option value="30">30°C以上</option>
			</select>
			<!-- 追加　10/26 -->
			<select class="question-11" name="airmode">
				<option value="-">選択してください</option>
				<option value="1">除湿（急）</option>
				<option value="2">除湿（強）</option>
				<option value="3">除湿（弱）</option>
				<option value="4">冷房（急）</option>
				<option value="5">冷房（強）</option>
				<option value="6">冷房（弱）</option>
				<option value="7">暖房（急）</option>
				<option value="8">暖房（強）</option>
				<option value="9">暖房（弱）</option>
			</select>
		</div>
		<div class="submit">
			<button id="submit-btn" >送信</button>
			<div class="error-message-area">
				<p id="error-message">快適度は必ず回答してください</p>
			</div>
		</div>
	</form>
	<footer>
		<div class="mirai-workspace">
			<a href="https://mirai-workspace.slack.com" target="_blank">
				<img src="images/slack.png" alt="slack" width="50px" height="50px">
			</a>
		</div>
		<div
		 class="copyright">2018 - now's Study
	 	</div>
	</footer>
	<script
	type="text/javascript" src="js/script.js">
	</script>
</body>
</html>
