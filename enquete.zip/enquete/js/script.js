$(function(){
  var questionFlg = [1,1,1,0,1,1,1,1];
  // スマホ判定
  var ua = navigator.userAgent;
    if (ua.indexOf('iPhone') > 0 || ua.indexOf('Android') > 0 && ua.indexOf('Mobile') > 0) {
        // スマートフォン用コード
        $('html').css('font-size','250%');
        $('input').css('transform','scale(2.0)').css('margin','0.5em');
	$('.error').css('font-size','250%');
    } else if (ua.indexOf('iPad') > 0 || ua.indexOf('Android') > 0) {
        // タブレット用コード
        $('html').css('font-size','150%');
        $('input').css('transform','scale(1.2)').css('margin','0.5em');
    } else {
        // PC用コード

    }

  //エアコン温度を入力後、送信ボタンを押下すると「全ての質問に回答してください」と表示され送信出来ないエラー
  // $('#form').submit(function(){
  //   // 回答が必須のものを全部していたら有効
  //   var retFlg = false;
  //   for(var i = 0; i < questionFlg.length; i++){
  //     if( questionFlg[i] === 1 ){
  //       retFlg = true;
  //       if($('[id=flg-1]').prop('checked')){
  //         if($('.question-10').val() !== '-'){
  //           retFlg = true;
  //         }else if($('.question-10').val() == '-'){
  //           retFlg = false;
  //           break;
  //         }
  //       }
  //     }else{
  //       retFlg = false;
  //       break;
  //     }
  //   }
  //   $('html,body').animate({
  //     'scrollTop': 1500
  //   }, 'slow');
  //   $('#error-message').hide();
  //   $("#error-message").animate(
  //     {
  //       height: "toggle",
  //       opacity: "toggle"
  //     },2000
  //   );
  //   console.log( retFlg );
  //   console.log( questionFlg );
  //   return retFlg;
  // });

  $('#form').submit(function(){
    if($('[name=comfort][value=0]').prop('checked')||$('[name=comfort][value=-1]').prop('checked')||$('[name=comfort][value=1]').prop('checked')){
      questionFlg[3]=1;
    }

    // 回答が必須のものを全部していたら有効
    var retFlg = false;
    var allChecked = false;
    for(var i = 0; i < questionFlg.length; i++){
      if( questionFlg[i] === 1 ){
        retFlg = true;
        if( i == questionFlg.length-1 ){
          allChecked = true;
        }
      }else{
        retFlg = false;
        break;
      }
    }

    if( allChecked ){
      if($('[id=flg-1]').prop('checked')){
        if($('.question-10').val() == '-' || $('.question-11').val() == '-'){
          retFlg = false;
        }
      }
      if(!$('[name=flg]').prop('checked')){
        $('[name=flg][value=0]').prop('checked', true);
      }
      if($('[name=place]').prop('value') == '-'){
        $('.question-2').val(1);
        $('[name=place]').val(1);
      }
    }

    $('#error-message').hide();
    if( !allChecked ){
      $("#error-message").animate(
        {
          height: "toggle",
          opacity: "toggle"
        },2000
      );
    }
    $('html,body').animate({
      'scrollTop': 1500
    }, 'slow');


    console.log( retFlg );
    console.log( questionFlg );
    return retFlg;
  });


  // 質問の必須項目フラグチェック
  // $('.gender-radio').change(function(){
  //   questionFlg[0] = 1;
  //   $('.where-class').slideDown();
  // });
  $('.where-class').change(function(){
    questionFlg[1] = 1;
    // $('.people-count').slideDown();
    $('.comfort-value').slideDown();
  });
  // $('.people-count').change(function(){
  //   questionFlg[2] = 1;
  //   $('.comfort-value').slideDown();
  // });
  $('.comfort-value').change(function(){
    questionFlg[3] = 1;
    // $('.window-open').slideDown();
    $('.airflg').slideDown();
  });
  // $('.window-open').change(function(){
  //   questionFlg[4] = 1;
  //   $('.blind-open').slideDown();
  //   $('html,body').animate({
  //     'scrollTop': 1500
  //   }, 'slow');
  // });
  // $('.blind-open').change(function(){
  //   questionFlg[5] = 1;
  //   $('.count-pc').slideDown();
  //   $('html,body').animate({
  //     'scrollTop': 1500
  //   }, 'slow');
  // });
  // $('.count-pc').change(function(){
  //   questionFlg[6] = 1;
  //   $('.airflg').slideDown();
  //   $('html,body').animate({
  //     'scrollTop': 1500
  //   }, 'slow');
  // });
  $('#flg-0').click(function(){
    questionFlg[7] = 1;
    $('.submit').slideDown();
    $('html,body').animate({
      'scrollTop': 1500
    }, 'slow');
  });
  $('.air-controll').change(function(){
    $('.submit').slideDown();
  });

  $('[name="flg"]:radio').change( function() {
    if($('[id=flg-1]').prop('checked')){
      $('.air-controll').slideDown();
    } else if ($('[id=flg-0]').prop('checked')) {
      questionFlg[7] = 1;
      $('.air-controll').slideUp();
    }
    $('html,body').animate({
      'scrollTop': 1500
    }, 'slow');
  });

  $('#debug-btn').click(function(){
    $('[name=gender][value=0]').prop('checked', true);
    $('.question-2').val(101);
    $('.question-3').val(5);
    $('[name=comfort][value=0]').prop('checked', true);
    $('[name=winopen][value=0]').prop('checked', true);
    $('[name=blindopen][value=0]').prop('checked', true);
    $('.question-8').val(0);
    $('[name=flg][value=0]').prop('checked', true);
    questionFlg = [1,1,1,1,1,1,1,1];
    $('.submit').show();
  });
});
